﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Elevi
{
    class Elev
    {
        public string nume, prenume, clasa;
        bool sex;
        bool bursier;
        List<int> medii;
        List<string> optionale;
        double mediaGenerala;

        public Elev(string nume_prenume, string clasa, List<int> medii, bool sex, List<string> optionale)
        {
            string[] s = nume_prenume.Split();
            this.nume = s[0];
            this.prenume = s[1];
            this.clasa = clasa;
            this.medii = medii;

            int suma = 0;
            foreach(int m in medii)
                suma += m;
            this.mediaGenerala = suma / medii.Count;

            this.sex = sex;
            this.bursier = (mediaGenerala >= 9.5);
            this.optionale = optionale;
        }
    }
}
