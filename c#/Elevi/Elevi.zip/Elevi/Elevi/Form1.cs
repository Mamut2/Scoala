﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Elevi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SortedDictionary<string, List<Elev>> elevi = new SortedDictionary<string, List<Elev>>();
        List<int> medii = new List<int>();
        List<string> optionale = new List<string>();

        private void textBox2_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && textBox2.Text != "")
            {
                textBox1.Text = (int.Parse(textBox1.Text) + 1).ToString();
                medii.Add(int.Parse(textBox2.Text));
                textBox2.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(checkBox1.Checked) optionale.Add("Romana");
            if(checkBox2.Checked) optionale.Add("Info");
            if(checkBox3.Checked) optionale.Add("Matematica");
            Elev el = new Elev(textBox3.Text, textBox4.Text, medii, radioButton1.Checked, optionale);
            if(!elevi.ContainsKey(el.clasa)) elevi.Add(el.clasa, new List<Elev>());
            elevi[el.clasa].Add(el);
            medii.Clear();
            optionale.Clear();

            textBox3.Clear();
            textBox4.Clear();
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            radioButton1.Checked = true;
            textBox1.Text = "1";

            UpdateTexbox5();
        }

        private void tabPage3_Enter(object sender, EventArgs e)
        {
            foreach (var key in elevi.Keys)
                if (!comboBox1.Items.Contains(key))
                    comboBox1.Items.Add(key);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTexbox5();
        }

        private void UpdateTexbox5()
        {
            textBox5.Text = "";
            foreach (var item in elevi)
                if (item.Key == (string)comboBox1.SelectedItem)
                    foreach (Elev el in item.Value)
                        textBox5.Text += el.nume + " " + el.prenume + "\r\n";
        }
    }
}
